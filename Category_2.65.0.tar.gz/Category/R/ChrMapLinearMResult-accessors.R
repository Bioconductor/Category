### DEPRECATED
setMethod("chrGraph", signature(r="ChrMapLinearMResult"),
          function(r) r@graph)
